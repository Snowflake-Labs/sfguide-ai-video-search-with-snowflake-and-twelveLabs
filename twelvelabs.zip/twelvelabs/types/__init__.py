from .index import IndexModel

__all__ = ["IndexModel"]
